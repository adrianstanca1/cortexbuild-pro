export const dynamic = "force-dynamic";
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const organizationId = session.user.organizationId;
    if (!organizationId) {
      return NextResponse.json({ error: 'No organization' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'overview';

    if (type === 'resource-allocation') {
      // Get team members with their project assignments and time entries
      const teamMembers = await prisma.teamMember.findMany({
        where: { organizationId },
        include: {
          user: { select: { id: true, name: true, email: true, avatarUrl: true } },
          projectAssignments: {
            include: {
              project: { select: { id: true, name: true, status: true } }
            }
          }
        }
      });

      // Get time entries for the last 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const timeEntries = await prisma.timeEntry.findMany({
        where: {
          project: { organizationId },
          date: { gte: thirtyDaysAgo }
        },
        include: {
          user: { select: { id: true, name: true } },
          project: { select: { id: true, name: true } }
        }
      });

      // Aggregate time by user
      const userTimeMap: Record<string, number> = {};
      timeEntries.forEach(entry => {
        userTimeMap[entry.userId] = (userTimeMap[entry.userId] || 0) + entry.hours;
      });

      // Get tasks by assignee (limited to 5000 recent tasks)
      const tasks = await prisma.task.findMany({
        where: {
          project: { organizationId },
          status: { not: 'COMPLETE' }
        },
        select: { assigneeId: true, priority: true },
        take: 5000
      });

      const tasksByUser: Record<string, { total: number; critical: number }> = {};
      tasks.forEach(task => {
        if (task.assigneeId) {
          if (!tasksByUser[task.assigneeId]) {
            tasksByUser[task.assigneeId] = { total: 0, critical: 0 };
          }
          tasksByUser[task.assigneeId].total++;
          if (task.priority === 'CRITICAL' || task.priority === 'HIGH') {
            tasksByUser[task.assigneeId].critical++;
          }
        }
      });

      const allocation = teamMembers.map(member => ({
        id: member.id,
        userId: member.user.id,
        name: member.user.name,
        email: member.user.email,
        avatarUrl: member.user.avatarUrl,
        jobTitle: member.jobTitle,
        projectCount: member.projectAssignments.length,
        projects: member.projectAssignments.map(pa => ({
          id: pa.project.id,
          name: pa.project.name,
          status: pa.project.status
        })),
        hoursLast30Days: userTimeMap[member.user.id] || 0,
        activeTasks: tasksByUser[member.user.id]?.total || 0,
        criticalTasks: tasksByUser[member.user.id]?.critical || 0,
        utilizationRate: Math.min(100, ((userTimeMap[member.user.id] || 0) / 160) * 100) // Assuming 160 hours/month capacity
      }));

      return NextResponse.json({ allocation });
    }

    if (type === 'budget-summary') {
      const projects = await prisma.project.findMany({
        where: { organizationId },
        include: {
          costItems: true,
          changeOrders: { where: { status: 'APPROVED' } },
          progressClaims: { where: { status: 'APPROVED' } }
        }
      });

      const summary = projects.map(project => {
        const originalBudget = project.budget || 0;
        const approvedCOs = project.changeOrders.reduce((sum: number, co: any) => sum + (co.costChange || 0), 0);
        const revisedBudget = originalBudget + approvedCOs;
        const actualSpend = project.costItems.reduce((sum: number, ci: any) => sum + (ci.actualAmount || 0), 0);
        const estimatedSpend = project.costItems.reduce((sum: number, ci: any) => sum + (ci.estimatedAmount || 0), 0);
        const claimed = project.progressClaims.reduce((sum: number, pc: any) => sum + (pc.thisClaim || 0), 0);

        return {
          id: project.id,
          name: project.name,
          status: project.status,
          originalBudget,
          approvedCOs,
          revisedBudget,
          actualSpend,
          estimatedSpend,
          claimed,
          variance: revisedBudget - actualSpend,
          variancePercent: revisedBudget > 0 ? ((revisedBudget - actualSpend) / revisedBudget) * 100 : 0,
          cpi: actualSpend > 0 ? estimatedSpend / actualSpend : 1
        };
      });

      const totals = summary.reduce((acc: any, p: any) => ({
        originalBudget: acc.originalBudget + p.originalBudget,
        revisedBudget: acc.revisedBudget + p.revisedBudget,
        actualSpend: acc.actualSpend + p.actualSpend,
        claimed: acc.claimed + p.claimed
      }), { originalBudget: 0, revisedBudget: 0, actualSpend: 0, claimed: 0 });

      return NextResponse.json({ projects: summary, totals });
    }

    if (type === 'schedule-health') {
      const projects = await prisma.project.findMany({
        where: { organizationId, status: 'IN_PROGRESS' },
        include: {
          tasks: { 
            select: { status: true, dueDate: true, priority: true },
            take: 1000  // Limit tasks per project
          },
          milestones: { 
            select: { status: true, targetDate: true, percentComplete: true },
            take: 100  // Limit milestones per project
          }
        },
        take: 100  // Limit number of projects
      });

      const health = projects.map(project => {
        const now = new Date();
        const taskMetrics = project.tasks.reduce((acc: any, t: any) => {
          if (t.status === 'COMPLETE') {
            acc.completedTasks++;
          } else if (t.dueDate && new Date(t.dueDate) < now) {
            acc.overdueTasks++;
          }
          acc.totalTasks++;
          return acc;
        }, { overdueTasks: 0, completedTasks: 0, totalTasks: 0 });

        const milestoneMetrics = project.milestones.reduce((acc: any, m: any) => {
          if (m.status === 'COMPLETED') {
            acc.completedMilestones++;
          } else if (new Date(m.targetDate) < now) {
            acc.overdueMilestones++;
          }
          if (new Date(m.targetDate) <= now) {
            acc.plannedMilestones++;
          }
          acc.totalMilestones++;
          return acc;
        }, { overdueMilestones: 0, completedMilestones: 0, totalMilestones: 0, plannedMilestones: 0 });

        // Calculate SPI
        const plannedProgress = milestoneMetrics.totalMilestones > 0
          ? milestoneMetrics.plannedMilestones / milestoneMetrics.totalMilestones
          : taskMetrics.totalTasks > 0 ? taskMetrics.completedTasks / taskMetrics.totalTasks : 0;
        const actualProgress = milestoneMetrics.totalMilestones > 0
          ? milestoneMetrics.completedMilestones / milestoneMetrics.totalMilestones
          : taskMetrics.totalTasks > 0 ? taskMetrics.completedTasks / taskMetrics.totalTasks : 0;
        const spi = plannedProgress > 0 ? actualProgress / plannedProgress : 1;

        let status = 'on-track';
        if (spi < 0.8) status = 'behind';
        else if (spi < 0.95) status = 'at-risk';
        else if (spi > 1.05) status = 'ahead';

        return {
          id: project.id,
          name: project.name,
          spi: Math.round(spi * 100) / 100,
          status,
          overdueTasks: taskMetrics.overdueTasks,
          overdueMilestones: milestoneMetrics.overdueMilestones,
          taskProgress: taskMetrics.totalTasks > 0 ? Math.round((taskMetrics.completedTasks / taskMetrics.totalTasks) * 100) : 0,
          milestoneProgress: milestoneMetrics.totalMilestones > 0 ? Math.round((milestoneMetrics.completedMilestones / milestoneMetrics.totalMilestones) * 100) : 0,
          endDate: project.endDate
        };
      });

      return NextResponse.json({ projects: health });
    }

    // Default: overview stats
    const [projectCount, taskCount, rfiCount, safetyCount] = await Promise.all([
      prisma.project.count({ where: { organizationId, status: 'IN_PROGRESS' } }),
      prisma.task.count({ where: { project: { organizationId }, status: { not: 'COMPLETE' } } }),
      prisma.rFI.count({ where: { project: { organizationId }, status: 'OPEN' } }),
      prisma.safetyIncident.count({ where: { project: { organizationId }, status: { in: ['OPEN', 'INVESTIGATING'] } } })
    ]);

    return NextResponse.json({
      activeProjects: projectCount,
      pendingTasks: taskCount,
      openRFIs: rfiCount,
      openSafetyIncidents: safetyCount
    });

  } catch (error) {
    console.error('Dashboard analytics error:', error);
    return NextResponse.json({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}
