import { AdminDashboardClient } from './_components/admin-dashboard-client';

// Force dynamic rendering
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function AdminPage() {
  return <AdminDashboardClient />;
}
